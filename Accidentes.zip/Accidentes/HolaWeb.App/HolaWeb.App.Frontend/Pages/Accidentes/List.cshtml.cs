using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HolaWeb.App.Persistencia.AppRepositorios;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using HolaWeb.App.Dominio;

namespace HolaWeb.App.Frontend.Pages
{
    public class ListModel : PageModel
    {
        //private string [] Accidentes = {"1","Latitud","Longitud","Direccion","FechaAccidente","Descripcion"};

        //public List<string> ListaAccidentes {get;set;}

        private readonly IRepositorioAccidente repositorioAccidentes;

        public IEnumerable<Accidente> Accidentes {get;set;}

        public ListModel(IRepositorioAccidente repositorioAccidentes)
        {
            this.repositorioAccidentes=repositorioAccidentes;
        }

        public void OnGet()
        {
            //ListaAccidentes = new List<string>();
            //ListaAccidentes.AddRange(Accidentes);

            Accidentes=repositorioAccidentes.GetAll();
        }
    }
}
