using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using HolaWeb.App.Persistencia.AppRepositorios;
using HolaWeb.App.Dominio;

namespace HolaWeb.App.Frontend.Pages
{
    public class DetalleModel : PageModel
    {

         private readonly IRepositorioAccidente repositorioAccidentes;

          public Accidente Accidente {get;set;}

          public DetalleModel(IRepositorioAccidente repositorioAccidentes)
        {
            this.repositorioAccidentes=repositorioAccidentes;
        }


        public IActionResult OnGet(int accidenteId)
        {
            Accidente=repositorioAccidentes.GetAccidentePorId(accidenteId);
            if (Accidente==null)
            {
                return RedirectToPage("../Error");
            }else {
                return Page();

            }

            
        }
    }
}
