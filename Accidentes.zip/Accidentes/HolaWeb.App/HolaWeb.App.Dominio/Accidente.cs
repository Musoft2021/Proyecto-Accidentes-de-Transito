﻿using System;

namespace HolaWeb.App.Dominio
{
    public class Accidente
    {
        public int Id {get;set;}
        public string Latitud {get;set;}
        public string Longitud {get;set;}
        public string Direccion {get;set;}
        public string FechaAccidente {get;set;}
        public string Descripcion {get;set;}
    }
}
