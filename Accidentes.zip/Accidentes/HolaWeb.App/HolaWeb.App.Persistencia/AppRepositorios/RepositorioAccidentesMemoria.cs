using System;
using System.Collections.Generic;
using System.Linq;
using HolaWeb.App.Dominio;


namespace HolaWeb.App.Persistencia.AppRepositorios
{
    public class RepositorioAccidentesMemoria : IRepositorioAccidente
    {
        
        List<Accidente> Accidentes;

        public RepositorioAccidentesMemoria()
        {
            Accidentes= new List<Accidente>()
            {
                new Accidente{Id=1,Latitud="75.52290F",Longitud="5.07062F",Direccion="Calle 127a N 70g-10",FechaAccidente="1990/04/12",Descripcion="Choque Multiple"},
                new Accidente{Id=2,Latitud="45.52290E",Longitud="4.07162F",Direccion="Transversa 116 N 35g-10",FechaAccidente="2021/09/30",Descripcion="Choque Moto y Vehiculo Particular"},
                new Accidente{Id=3,Latitud="55.43290F",Longitud="6.17062F",Direccion="Calle 129a N 99g-11",FechaAccidente="2021/10/09",Descripcion="Choque Biciclete y Vehiculo Particular 1 herido"}

            };
        } 
        public IEnumerable<Accidente> GetAll()
        {
            return Accidentes;
        }

        public Accidente GetAccidentePorId(int IdAccidente)
        {
            return Accidentes.SingleOrDefault(a => a.Id==IdAccidente);
        }

        //public IEnumerable<Accidente> GetAccidentePorFiltro(string filtro=null)
        //{
          //  var Accidente = GetAll();
            //if (Accidente != null);
             //return Accidente;
            
        //}
       
    }
}