using System;
namespace AcciPro.App.Dominio
{
    public class TipoVehiculo
    {
       public int id {get;set;}
        public string Descripcion {get;set;}
       
    }
}