using System;
namespace AcciPro.App.Dominio
{
    public class Persona
    {
       public int Id {get;set;}
        public string Nombre {get;set;}
        public string Apellido {get;set;}
        public string Sexo {get;set;}
        public string edad {get;set;}  
    }
}