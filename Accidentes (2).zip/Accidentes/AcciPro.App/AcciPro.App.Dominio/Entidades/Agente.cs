using System;
namespace AcciPro.App.Dominio
{
    public class Agente : Persona
    {

    }
}