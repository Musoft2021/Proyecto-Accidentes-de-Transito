using System;
namespace AcciPro.App.Dominio
{
    public class EventoAccidente
    {
       public int Id {get;set;}
        public int id_persona {get;set;}
        public int id_agente {get;set;}
        public int id_vehiculo {get;set;}
        public int Id_accidente {get;set;}  
    }
}