﻿using System;
using AcciPro.App.Dominio;
using AcciPro.App.Persistencia;

namespace AcciPro.App.Consola
{
    class Program
    {
        private static IRepositorioPersona _repoPersona= new RepositorioPersona(new Persistencia.AppContext());
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World EF!");
            //AddPersona();
            BuscarPersona(1);
        }

        private static void AddPersona()
        {
            var persona = new Persona 
            {
                
                Nombre="Nicolay",
                Apellido="Perez",
                Sexo="Masculino",
                edad="26"
            };

            _repoPersona.AddPersona(persona);
         }
    
    
        private static void BuscarPersona(int idPersona)
        {
        var persona = _repoPersona.GetPersona(idPersona);
        Console.WriteLine(persona.Nombre+" "+persona.Apellido);
        }

    }

}

