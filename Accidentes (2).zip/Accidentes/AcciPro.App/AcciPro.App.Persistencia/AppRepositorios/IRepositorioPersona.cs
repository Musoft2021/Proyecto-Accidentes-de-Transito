using System.Collections.Generic;
using AcciPro.App.Dominio;


namespace AcciPro.App.Persistencia
{
    public interface IRepositorioPersona
    {
        IEnumerable<Persona> GetAllPersonas();
        Persona AddPersona(Persona Persona);
        
        Persona UpdatePersona(Persona Persona);
        
        void DeletePersona(int idPersona);
        Persona GetPersona(int idPersona);
        
           }
}